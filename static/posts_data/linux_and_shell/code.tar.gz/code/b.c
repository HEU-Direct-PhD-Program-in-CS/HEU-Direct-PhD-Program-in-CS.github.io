#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>

#define ESCAPE_CODE "\x1b[34m"
#define log_printf(fmt, ...) printf(ESCAPE_CODE fmt, ##__VA_ARGS__)

void* base_addr = (void*)(0x800000);


int main() {
    FILE* fp = fopen("./b.txt", "r+");
    int *b = (int*)mmap(base_addr, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fileno(fp), 0);
    fclose(fp);

    log_printf("b = %p\n", b);
    for (int i = 0; i < 10; i++) {
        b[i] = i + i * 2;
    }
    log_printf("b[]: ");
    for (int i = 0; i < 10; i++) {
        log_printf("%4d ", b[i]);
    }
    log_printf("\n[b.exe]: sleep 1 sec...\n");
    
    sleep(1);

    log_printf("a[]: ");
    for (int i = 0; i < 10; i++) {
        log_printf("%4d ", b[i]);
    }
    putchar('\n');
}