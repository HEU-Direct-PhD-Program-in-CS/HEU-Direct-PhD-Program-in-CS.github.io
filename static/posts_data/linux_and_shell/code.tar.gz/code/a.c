#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>

#define ESCAPE_CODE "\x1b[31m"
#define log_printf(fmt, ...) printf(ESCAPE_CODE fmt, ##__VA_ARGS__)

void* base_addr = (void*)(0x800000);


int main() {
    FILE* fp = fopen("./a.txt", "r+");
    int *a = (int*)mmap(base_addr, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fileno(fp), 0);
    fclose(fp);

    log_printf("a = %p\n", a);
    for (int i = 0; i < 10; i++) {
        a[i] = i * i + 2;
    }
    log_printf("a[]: ");
    for (int i = 0; i < 10; i++) {
        log_printf("%4d ", a[i]);
    }
    log_printf("\n[a.exe]: sleep 1 sec...\n");
    
    sleep(1);

    log_printf("b[]: ");
    for (int i = 0; i < 10; i++) {
        log_printf("%4d ", a[i]);
    }
    putchar('\n');
}